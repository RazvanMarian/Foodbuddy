module.exports = {
    MONGOURI: "mongodb+srv://razvan:SDvb1b7STT1SKSzy@cluster0.lc4yu.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",
    JWT_SECRET: "ywD5gGkW0zy2kc63QcWv"
}